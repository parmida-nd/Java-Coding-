import java.util.HashMap;
import java.util.Map;

/**
 * A class to validate and interpret Canadian postal codes.
 * Provides methods to check postal code validity, retrieve the corresponding province, 
 * and determine if the address is urban or rural.
 * @author Parmida Niroomand - 202313971 
 */
public class PostalCodeChecker {
    private Map<Character, String> provinceMap;

    /**
     * Constructor to initialize the province mappings for Canadian postal codes.
     */
    public PostalCodeChecker() {
        provinceMap = new HashMap<>();
        provinceMap.put('A', "Newfoundland and Labrador");
        provinceMap.put('B', "Nova Scotia");
        provinceMap.put('C', "Prince Edward Island");
        provinceMap.put('E', "New Brunswick");
        provinceMap.put('G', "Quebec");
        provinceMap.put('H', "Quebec");
        provinceMap.put('J', "Quebec");
        provinceMap.put('K', "Ontario");
        provinceMap.put('L', "Ontario");
        provinceMap.put('M', "Ontario");
        provinceMap.put('N', "Ontario");
        provinceMap.put('P', "Ontario");
        provinceMap.put('R', "Manitoba");
        provinceMap.put('S', "Saskatchewan");
        provinceMap.put('T', "Alberta");
        provinceMap.put('V', "British Columbia");
        provinceMap.put('X', "Nunavut or Northwest Territories");
        provinceMap.put('Y', "Yukon");
    }

    /**
     * Validates the format and the first character of a postal code.
     * 
     * @param postalCode The postal code to validate.
     * @return true if the postal code is valid; false otherwise.
     */
    public boolean isValidPostalCode(String postalCode) {
        if (postalCode == null || postalCode.length() != 7 || postalCode.charAt(3) != ' ') {
            return false;
        }
        char firstChar = postalCode.charAt(0);
        char secondChar = postalCode.charAt(1);
        char thirdChar = postalCode.charAt(2);
        char fifthChar = postalCode.charAt(4);
        char sixthChar = postalCode.charAt(5);

        // Check if characters are valid
        return provinceMap.containsKey(firstChar) &&
               Character.isDigit(secondChar) &&
               Character.isLetter(thirdChar) &&
               Character.isDigit(fifthChar) &&
               Character.isLetter(sixthChar);
    }

    /**
     * Retrieves the province associated with the first character of a valid postal code.
     * 
     * @param postalCode The postal code to analyze.
     * @return The province name as a String.
     */
    public String getProvince(String postalCode) {
        return provinceMap.get(postalCode.charAt(0));
    }

    /**
     * Determines whether the address is urban or rural based on the second character.
     * 
     * @param postalCode The postal code to analyze.
     * @return "Urban" if the second character is not 0; "Rural" otherwise.
     */
    public String getAddressType(String postalCode) {
        return postalCode.charAt(1) == '0' ? "Rural" : "Urban";
    }
}

