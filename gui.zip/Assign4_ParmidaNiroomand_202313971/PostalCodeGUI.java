import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * PostalCodeGUI is a graphical user interface (GUI) for the Canadian Postal Code Checker application. 
 * This GUI allows users to input a Canadian postal code, validate its format, and display the corresponding 
 * province and address type (rural or urban). It also handles error messages for invalid postal codes.
 * 
 * The PostalCodeGUI class relies on the PostalCodeChecker class to validate postal codes and provide 
 * province and address type information.
 */
public class PostalCodeGUI 
{
    private PostalCodeChecker checker;

     /**
     * Constructs a new PostalCodeGUI instance, initializes the PostalCodeChecker, 
     * and sets up the graphical components of the user interface.
     */
    public PostalCodeGUI() 
    {
        checker = new PostalCodeChecker();

        // Create GUI components
        JFrame frame = new JFrame("Canadian Postal Code Checker");
        JLabel inputLabel = new JLabel("Enter Postal Code:");
        JTextField inputField = new JTextField(10);
        JButton checkButton = new JButton("Check Postal Code");
        JLabel resultLabel = new JLabel();
        JLabel errorLabel = new JLabel();

        // Set up layout
        frame.setLayout(new java.awt.FlowLayout());
        frame.add(inputLabel);
        frame.add(inputField);
        frame.add(checkButton);
        frame.add(resultLabel);
        frame.add(errorLabel);

        // Action listener for the check button
        checkButton.addActionListener(new ActionListener()
        {
            /**
             * Handles the button click event for checking the postal code. 
             * Validates the postal code, displays the corresponding province and address type,
             * or shows an error message for invalid input.
             *
             * @param e The action event triggered by the button click.
             */
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String postalCode = inputField.getText().toUpperCase().trim();
                if (checker.isValidPostalCode(postalCode)) 
                {
                    String province = checker.getProvince(postalCode);
                    String addressType = checker.getAddressType(postalCode);
                    resultLabel.setText("Province: " + province + ", Address: " + addressType);
                    errorLabel.setText(""); // Clear error message
                } else 
                {
                    resultLabel.setText("");
                    errorLabel.setText("Invalid postal code. It begins with an invalid character or has an incorrect format.");
                }
            }
        });

        // Finalize frame setup
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    /**
     * Main method that runs the application. Initializes the PostalCodeGUI and displays the window.
     * 
     * @param args Command line arguments (not used in this program).
     */
    public static void main(String[] args) 
    {
        new PostalCodeGUI();
    }
}





